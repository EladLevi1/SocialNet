﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructuresProjectEladLevi
{
    [Serializable]
    internal class DatesComparer : IEqualityComparer<DateTime>
    {
        public bool Equals(DateTime x, DateTime y)
        {
            return x.Month == y.Month && x.Day == y.Day;
        }
        public int GetHashCode(DateTime obj)
        {
            return obj.Month.GetHashCode() ^ obj.Day.GetHashCode();
        }
    }
}
