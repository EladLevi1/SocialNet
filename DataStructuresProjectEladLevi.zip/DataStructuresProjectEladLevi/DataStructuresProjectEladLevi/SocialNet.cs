﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;
using Windows.System;

namespace DataStructuresProjectEladLevi
{
    [Serializable]
    internal class SocialNet
    {
        private Graph<User> social;
        private Dictionary<DateTime, List<User>> birthdays;
        private static int lastestSetID = 1000;
        public SocialNet()
        {
            social = new Graph<User>();
            birthdays= new Dictionary<DateTime, List<User>>(new DatesComparer());
            Load();
        }
        private void FirstCreatingItems()
        {
            User u1 = new User("Elad", new DateTime(2001, 06, 23), Hobbies.Writing | Hobbies.Gaming | Hobbies.Sports, 1000);
            User u2 = new User("Yoav", new DateTime(1997, 04, 01), Hobbies.HorsebackRiding | Hobbies.Reading | Hobbies.Archery, 1001);
            User u3 = new User("Tal", new DateTime(2002, 04, 03), Hobbies.Astronomy | Hobbies.Archery | Hobbies.Painting, 1002);
            User u4 = new User("Tamir", new DateTime(2003, 04, 10), Hobbies.Calligraphy | Hobbies.BirdWatching | Hobbies.Embroidery, 1003);

            lastestSetID = 1004;

            social.AddVertex(u1);
            social.AddVertex(u2);
            social.AddVertex(u3);
            social.AddVertex(u4);

            birthdays[u1.GetBirthDay] = new List<User>();
            birthdays[u2.GetBirthDay] = new List<User>();
            birthdays[u3.GetBirthDay] = new List<User>();
            birthdays[u4.GetBirthDay] = new List<User>();

            birthdays[u1.GetBirthDay].Add(u1);
            birthdays[u2.GetBirthDay].Add(u2);
            birthdays[u3.GetBirthDay].Add(u3);
            birthdays[u4.GetBirthDay].Add(u4);

            Post p1 = new Post("First", "FirstFirst", new DateTime(2022, 01, 01));
            Post p2 = new Post("Second", "SecondSecond", new DateTime(2022, 02, 01));
            Post p3 = new Post("Third", "ThirdThird", new DateTime(2022, 03, 01));
            Post p4 = new Post("Forth", "ForthForth", new DateTime(2022, 04, 01));
            Post p5 = new Post("Fifth", "FifthFifth", new DateTime(2022, 05, 01));
            Post p6 = new Post("Sixth", "SixthSixth", new DateTime(2022, 06, 01));
            Post p7 = new Post("Seventh", "SeventhSeventh", new DateTime(2022, 07, 01));
            Post p8 = new Post("Eight", "EightEight", new DateTime(2022, 08, 01));
            Post p9 = new Post("Ninth", "NinthNinth", new DateTime(2022, 09, 01));
            Post p10 = new Post("Tenth", "TenthTenth", new DateTime(2022, 10, 01));
            Post p11 = new Post("BetweenSixthAndSeventh", "TryintTINBetweenSixthAndSeventhBetweenSixthAndSeventh", new DateTime(2022, 06, 25));

            AddPost(u1, p1);
            AddPost(u1, p2);
            AddPost(u1, p3);
            AddPost(u1, p4);
            AddPost(u1, p5);
            AddPost(u1, p6);
            AddPost(u1, p7);
            AddPost(u1, p8);
            AddPost(u1, p9);
            AddPost(u1, p10);
            AddPost(u1, p11);
        }
        private async void Load()
        {
            BinaryFormatter bf = new BinaryFormatter();
            StorageFolder localFolder = ApplicationData.Current.LocalFolder;
            try
            {
                StorageFile file = await localFolder.GetFileAsync("social.dat");
                string filePath = file.Path;
                using (Stream stream = await file.OpenStreamForReadAsync())
                {
                    social = (Graph<User>)bf.Deserialize(stream);
                    birthdays = (Dictionary<DateTime, List<User>>)bf.Deserialize(stream);
                    lastestSetID = (int)bf.Deserialize(stream);
                    stream.Close();
                }
            }
            catch (FileNotFoundException)
            {
                FirstCreatingItems();
                Save();
            }
            catch (Exception)
            {
                FirstCreatingItems();
                Save();
            }
        }
        public async void Save()
        {
            BinaryFormatter bf = new BinaryFormatter();
            StorageFolder localFolder = ApplicationData.Current.LocalFolder;
            try
            {
                StorageFile file = await localFolder.CreateFileAsync("social.dat", CreationCollisionOption.ReplaceExisting);
                using (Stream stream = await file.OpenStreamForWriteAsync())
                {
                    bf.Serialize(stream, social);
                    bf.Serialize(stream, birthdays);
                    bf.Serialize(stream, lastestSetID);
                    stream.Close();
                }
            }
            catch (Exception) { }
        }
        public int GetLastestID { get { return lastestSetID; } }
        private List<User> GetUsers { get { return social.GetVertices(); } }
        public List<int> GetID
        {
            get
            {
                List<int> ids = new List<int>();
                foreach (User user in social.GetVertices())
                {
                    ids.Add(user.GetID);
                }
                return ids;
            }
        }
        public List<string> GetUsernamesAndID
        {
            get
            {
                List<string> names = new List<string>();
                foreach (User user in social.GetVertices())
                {
                    string id = user.GetID.ToString();
                    names.Add(user.GetName + " - " + id);
                }
                return names;
            }
        }
        public User GetUserByID(int ID)
        {
            foreach (User user in GetUsers)
            {
                if (user.GetID == ID)
                {
                    return user;
                }
            }
            throw new Exceptions.UserNotExistException();
        }
        public void AddUser(User user)
        {
            if (CheckIfUserExist(user))
                throw new Exceptions.UserExistException();
            social.AddVertex(user);
            lastestSetID++;
            if (!birthdays.ContainsKey(user.GetBirthDay))
            {
                birthdays[user.GetBirthDay] = new List<User>();
            }
            birthdays[user.GetBirthDay].Add(user);
            Save();
        }
        public void RemoveUser(User user)
        {
            if (!CheckIfUserExist(user))
                throw new Exceptions.UserNotExistException();
            social.RemoveVertex(user);
            birthdays[user.GetBirthDay].Remove(user);
            Save();
        }
        public void AddFriend(User user1, User user2)
        {
            if (!(CheckIfUserExist(user1) && CheckIfUserExist(user2)))
                throw new Exceptions.UserNotExistException();
            if (social.AreNeighbours(user1, user2))
                throw new Exceptions.UsersAlreadyFriendsException();
            social.AddEdge(user1, user2);
            Save();
        }
        public void RemoveFriend(User user1, User user2)
        {
            if (!(CheckIfUserExist(user1) && CheckIfUserExist(user2)))
                throw new Exceptions.UserNotExistException();
            if (!social.AreNeighbours(user1, user2))
                throw new Exceptions.UsersNotFriendsException();
            social.RemoveEdge(user1, user2);
            Save();
        }
        public void AddHobbies(User user, Hobbies hobby)
        {
            if (!CheckIfUserExist(user))
                throw new Exceptions.UserNotExistException();
            user.AddHobby(hobby);
            Save();
        }
        public void RemoveHobbiers(User user, Hobbies hobby)
        {
            if (!CheckIfUserExist(user))
                throw new Exceptions.UserNotExistException();
            user.RemoveHobby(hobby);
            Save();
        }
        public List<User> FriendsList(User user)
        {
            if (!CheckIfUserExist(user))
                throw new Exceptions.UserNotExistException();
            return social.GetNeigbours(user);
        }
        public List<User> PeopleYouMayKnow(User user)
        {
            if (!CheckIfUserExist(user))
                throw new Exceptions.UserNotExistException();
            List<User> list = new List<User>();
            foreach (var friend in social.GetNeigbours(user))
            {
                if (!CheckIfUserExist(friend))
                    throw new Exceptions.UserNotExistException();
                foreach (var friendoffriend in social.GetNeigbours(friend))
                {
                    if (!CheckIfUserExist(friendoffriend))
                        throw new Exceptions.UserNotExistException();
                    if (!social.AreNeighbours(user, friendoffriend) && friendoffriend.GetID != user.GetID)
                    {
                        list.Add(friendoffriend);
                    }
                }
            }
            return list;
        }
        public string ShowUserInfo(User user)
        {
            if (CheckIfUserExist(user))
                return user.ToString();
            throw new Exceptions.UserNotExistException();
        }
        public List<User> GetTodaysBirthday(DateTime date)
        {
            List<User> bday = new List<User>();
            if (!birthdays.ContainsKey(date))
                throw new Exceptions.NoBirthdaysInThisDateException();
            foreach (var user in birthdays[date])
                bday.Add(user);
            return bday;
        }
        public void AddPost(User user, Post post)
        {
            if (!CheckIfUserExist(user))
                throw new Exceptions.UserNotExistException();
            user.AddPost(post);
            Save();
        }
        public string ShowPost(User user, Post post)
        {
            if (CheckIfUserExist(user))
                return user.ShowPost(post);
            throw new Exceptions.UserNotExistException();
        }
        public List<string> ShowPostsByUserByDates(User user, DateTime dateFrom, DateTime dateTo)
        {
            if (CheckIfUserExist(user))
                return user.ShowPostsByDate(dateFrom, dateTo);
            throw new Exceptions.UserNotExistException();
        }
        private bool CheckIfUserExist(User user)
        {
            if (social.GetVertices().Contains(user))
                return true;
            return false;
        }
    }
}
