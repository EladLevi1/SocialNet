﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructuresProjectEladLevi
{
    public class Exceptions : Exception
    {
        public class VertexExistException : Exception
        {
            public VertexExistException() { }
            public override string Message => "The vertex is already exist!";
        }
        public class VertexNotExistException : Exception
        {
            public VertexNotExistException() { }
            public override string Message => "The vertex is not exist!";
        }
        public class UserExistException : Exception
        {
            public UserExistException() { }
            public override string Message => "The user is already exist!";
        }
        public class UserNotExistException : Exception
        {
            public UserNotExistException() { }
            public override string Message => "The user is not exist!";
        }
        public class PostExistException : Exception
        {
            public PostExistException() { }
            public override string Message => "The post is already exist!";
        }
        public class PostNotExistException : Exception
        {
            public PostNotExistException() { }
            public override string Message => "The post is not exist!";
        }
        public class UsersAlreadyFriendsException : Exception
        {
            public UsersAlreadyFriendsException() { }
            public override string Message => "The users are already friends!";
        }
        public class UsersNotFriendsException : Exception
        {
            public UsersNotFriendsException() { }
            public override string Message => "The users are not friends!";
        }
        public class NoBirthdaysInThisDateException : Exception
        {
            public NoBirthdaysInThisDateException() { }
            public override string Message => "There are no users celebrating a birthday in this date!";
        }
    }
}
