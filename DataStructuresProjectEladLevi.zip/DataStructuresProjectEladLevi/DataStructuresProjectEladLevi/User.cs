﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace DataStructuresProjectEladLevi
{
    [Serializable]
    internal class User
    {
        private string name;
        private DateTime birthday;
        private Hobbies hobbies;
        private SortedSet<Post> posts;
        public readonly int id;
        public User(string name, DateTime birthday, Hobbies hobbies, int id)
        {
            this.name = name;
            this.birthday = birthday;
            this.hobbies = hobbies;
            this.posts = new SortedSet<Post>(Comparer<Post>.Create((p1, p2) => p1.GetPostDate.CompareTo(p2.GetPostDate)));
            this.id = id;
        }
        public int GetID { get { return id; } }
        public string GetName { get { return name; } }
        public SortedSet<Post> GetPosts { get { return posts; } }
        public DateTime GetBirthDay { get { return birthday; } }
        public Hobbies GetHobbies { get { return hobbies; } }
        public void AddHobby(Hobbies hobby)
        {
            hobbies |= hobby;
        }
        public void RemoveHobby(Hobbies hobby)
        {
            hobbies -= hobby;
        }
        public void AddPost(Post post)
        {
            if (posts.Contains(post))
                throw new Exceptions.PostExistException();
            posts.Add(post);
        }
        public string ShowPost(Post post)
        {
            if (posts.Contains(post))
                return post.ToString();
            throw new Exceptions.PostNotExistException();
        }
        public List<string> ShowPostsByDate(DateTime dateFrom, DateTime dateTo)
        {
            //Option 1
            List<string> postsByDate = new List<string>();
            var filteredPosts = posts.Where(post => post.GetPostDate.Date >= dateFrom && post.GetPostDate.Date <= dateTo);
            foreach (var post in filteredPosts)
            {
                postsByDate.Add(post.GetTitleAndDate + "\n");
            }
            return postsByDate;

            //Option 2
            //var view = posts.GetViewBetween(new Post("Title", "Body", dateFrom), new Post("Title", "Body", dateTo));
            //foreach (var post in view)
            //{
            //    postsByDate.Add(post.GetTitleAndDate + "\n");
            //}
            //return postsByDate;
        }
        public override string ToString()
        {
            return $"Name: {name}\n" +
                $"Birthday: {birthday:d}\n" +
                $"Hobbies: {hobbies}\n" +
                $"Posts: {posts.Count}\n";
        }
    }
    [Flags]
    public enum Hobbies : ulong
    {
        Writing = 1,
        Blogging = 2,
        Podcasting = 4,
        Marketing = 8,
        Photography = 16,
        Travel = 32,
        Sports = 64,
        Yoga = 128,
        Dance = 256,
        Art = 512,
        Reading = 1024,
        Cooking = 2048,
        Gaming = 4096,
        Music = 8192,
        Collecting = 16384,
        Gardening = 32768,
        Fishing = 65536,
        Hiking = 131072,
        Camping = 262144,
        DIY = 524288,
        BoardGames = 1048576,
        FilmMaking = 2097152,
        Woodworking = 4194304,
        Drawing = 8388608,
        Painting = 16777216,
        Calligraphy = 33554432,
        Origami = 67108864,
        Knitting = 134217728,
        Sewing = 268435456,
        Embroidery = 536870912,
        Coding = 1073741824,
        Running = 2147483648,
        Cycling = 4294967296,
        Swimming = 8589934592,
        Surfing = 17179869184,
        Skateboarding = 34359738368,
        Snowboarding = 68719476736,
        Skiing = 137438953472,
        HorsebackRiding = 274877906944,
        Archery = 549755813888,
        Climbing = 1099511627776,
        MartialArts = 2199023255552,
        Meditation = 4398046511104,
        Volunteering = 8796093022208,
        Astronomy = 17592186044416,
        BirdWatching = 35184372088832,
        BoardSports = 70368744177664,
        Bowling = 140737488355328,
        Chess = 281474976710656,
        Magic = 562949953421312,
        ModelBuilding = 1125899906842624
    }
}
