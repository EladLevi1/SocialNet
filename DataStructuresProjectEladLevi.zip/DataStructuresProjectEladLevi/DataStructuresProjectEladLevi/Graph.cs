﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructuresProjectEladLevi
{
    [Serializable]
    internal class Graph<E>
    {
        private Dictionary<E, List<E>> dic = new Dictionary<E, List<E>>();
        public void AddVertex(E ver)
        {
            if (dic.ContainsKey(ver))
                throw new Exceptions.VertexExistException();
            dic.Add(ver, new List<E>());
        }
        public void RemoveVertex(E ver)
        {
            if (!dic.ContainsKey(ver))
                throw new Exceptions.VertexNotExistException();
            dic.Remove(ver);
        }
        public void AddEdge(E ver1, E ver2)
        {
            if (!(dic.ContainsKey(ver1) && dic.ContainsKey(ver2)))
                throw new Exceptions.VertexNotExistException();
            dic[ver1].Add(ver2);
            dic[ver2].Add(ver1);
        }
        public void RemoveEdge(E ver1, E ver2)
        {
            if (!(dic.ContainsKey(ver1) && dic.ContainsKey(ver2)))
                throw new Exceptions.VertexNotExistException();
            dic[ver1].Remove(ver2);
            dic[ver2].Remove(ver1);
        }
        public bool AreNeighbours(E ver1, E ver2)
        {
            if (dic[ver1].Contains(ver2))
                return true;
            return false;
        }
        public List<E> GetNeigbours(E ver)
        {
            if (dic.ContainsKey(ver))
                return dic[ver];
            throw new Exceptions.VertexNotExistException();
        }
        public List<E> GetVertices()
        {
            List<E> list = new List<E>();
            foreach (var v in dic.Keys)
            {
                list.Add(v);
            }
            return list;
        }
        public List<E> BFS(E from, E to)
        {
            if (!(dic.ContainsKey(from) && dic.ContainsKey(to)))
                throw new Exceptions.VertexNotExistException();
            Dictionary<E, E> father = new Dictionary<E, E>();
            List<E> visited = new List<E>();
            Queue<E> queue = new Queue<E>();
            bool found = false;
            queue.Enqueue(from);
            while (queue.Count > 0)
            {
                var temp = queue.Dequeue();
                visited.Add(temp);
                if (temp.Equals(to))
                {
                    found = true;
                    break;
                }
                List<E> list = GetNeigbours(temp);
                if (list.Count > 0)
                {
                    foreach (E e in list)
                    {
                        if (!visited.Contains(e))
                        {
                            queue.Enqueue(e);
                            father[e] = temp;
                        }
                    }
                }
            }
            if (!found)
                return null;
            List<E> path = new List<E>();
            E current = to;
            while (!current.Equals(from))
            {
                path.Add(current);
                current = father[current];
            }
            path.Add(from);
            path.Reverse();
            return path;
        }
    }
}