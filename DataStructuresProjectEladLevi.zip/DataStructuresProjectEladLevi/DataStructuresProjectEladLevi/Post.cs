﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructuresProjectEladLevi
{
    [Serializable]
    internal class Post
    {
        private DateTime date;
        private string title;
        private string body;
        public Post(string title, string body, DateTime date = default(DateTime))
        {
            this.title = title;
            this.body = body;
            if (date != default(DateTime))
                this.date = date;
            else
                this.date = DateTime.Now;
        }
        public DateTime GetPostDate { get { return date; } }
        public string GetTitle { get { return title; } }
        public string GetBody { get { return body; } }
        public string GetTitleAndDate { get { return $"{title} - {date:d}"; } }
        public override string ToString()
        {
            string post = string.Empty;
            post += $"Post title:\n{title}\nPost body:\n{body}\nPost date:\n{date:d}";
            return post;
        }
    }
}
