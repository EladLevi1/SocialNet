﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;
using Windows.System;
using Windows.UI.Xaml.Media;

namespace DataStructuresProjectEladLevi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Part 1:
            Graph<int> g = new Graph<int>();
            g.AddVertex(13);
            g.AddVertex(10);
            g.AddVertex(9);
            g.AddVertex(2);
            g.AddVertex(5);
            g.AddVertex(1);
            g.AddEdge(13, 10);
            g.AddEdge(13, 5);
            g.AddEdge(10,2);
            g.AddEdge(2, 1);
            g.AddEdge(5, 1);
            g.AddEdge(5, 9);
            Console.WriteLine(string.Join(" => ", g.BFS(10, 9)) + "\n\n\n\n");

            // Part 2:
            SocialNet socialNet = new SocialNet();
            DateTime date = DateTime.Today.Date;
            bool stop = false;
            while (!stop)
            {
                Console.WriteLine($"Current date: {date:d}\n\n" +
                    "Choose option:\n" +
                    "1 - Add User\n" +
                    "2 - Remove User\n" +
                    "3 - Add Friend\n" +
                    "4 - Remove Friend\n" +
                    "5 - Add Hobby\n" +
                    "6 - Remove Hobby\n" +
                    "7 - Friend List\n" +
                    "8 - People You Might Know\n" +
                    "9 - User Information\n" +
                    "10 - Add Post\n" +
                    "11 - Show Post\n" +
                    "12 - Show Posts By Date\n" +
                    "13 - Show Today's Birthdays\n" +
                    "14 - Step One Day\n" +
                    "15 - Exit");
                int choose;
                while (!int.TryParse(Console.ReadLine(), out choose) || choose > 15 || choose < 1)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid option, try again!");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                switch (choose)
                {
                    case 1:
                        Option1(socialNet);
                        Console.Clear();
                        break;
                    case 2:
                        Option2(socialNet);
                        Console.Clear();
                        break;
                    case 3:
                        Option3(socialNet);
                        Console.Clear();
                        break;
                    case 4:
                        Option4(socialNet);
                        Console.Clear();
                        break;
                    case 5:
                        Option5(socialNet);
                        Console.Clear();
                        break;
                    case 6:
                        Option6(socialNet);
                        Console.Clear();
                        break;
                    case 7:
                        Option7(socialNet);
                        Console.Clear();
                        break;
                    case 8:
                        Option8(socialNet);
                        Console.Clear();
                        break;
                    case 9:
                        Option9(socialNet);
                        Console.Clear();
                        break;
                    case 10:
                        Option10(socialNet);
                        Console.Clear();
                        break;
                    case 11:
                        Option11(socialNet);
                        Console.Clear();
                        break;
                    case 12:
                        Option12(socialNet);
                        Console.Clear();
                        break;
                    case 13:
                        Option13(socialNet, date);
                        Console.Clear();
                        break;
                    case 14:
                        Option14(ref date);
                        Console.Clear();
                        break;
                    case 15:
                        stop = true;
                        Environment.Exit(0);
                        break;
                }
            }
        }
        private static void Option1(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 1 was chosen, moving to adding a new user system.\n");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Enter your user name:");
            Console.ForegroundColor = ConsoleColor.White;
            string name = Console.ReadLine();
            while (true)
            {
                if (Regex.IsMatch(name, @"^[a-zA-Z]+$"))
                {
                    name = name[0].ToString().ToUpper() + name.Substring(1, name.Length - 1).ToLower();
                    break;
                }
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid name, try again!");
                Console.ForegroundColor = ConsoleColor.White;
                name = Console.ReadLine();
            }
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter your birthday (DD/MM/YYYY):");
            Console.ForegroundColor = ConsoleColor.White;
            DateTime birthday;
            while (true)
            {
                if (DateTime.TryParse(Console.ReadLine(), out birthday))
                {
                    if (birthday < DateTime.Today.Date)
                        break;
                }
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid date, try again!");
                Console.ForegroundColor = ConsoleColor.White;
            }
            Console.WriteLine("");
            List<string> hobbiesList = new List<string>();
            foreach (Hobbies h in (Hobbies[])Enum.GetValues(typeof(Hobbies)))
            {
                hobbiesList.Add(h.ToString());
            }
            int colCount = 4;
            int rowCount = (int)Math.Ceiling((double)hobbiesList.Count / colCount);
            for (int i = 0; i < rowCount; i++)
            {
                for (int j = 0; j < colCount; j++)
                {
                    int index = i + j * rowCount;
                    if (index < hobbiesList.Count)
                    {
                        Console.Write(hobbiesList[index].PadRight(20));
                    }
                }
                Console.WriteLine();
            }
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter all your hobbies (type 'STOP' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            Hobbies hobbies = new Hobbies();
            string hob = Console.ReadLine();
            while (!string.Equals(hob, "STOP", StringComparison.OrdinalIgnoreCase))
            {
                if (Enum.TryParse(hob, true, out Hobbies h))
                {
                    hobbies |= h;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"Invalid hobby: {hob}");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                hob = Console.ReadLine();
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\nUser {name} added successfully!\n");
            Console.ForegroundColor = ConsoleColor.White;
            User user = new User(name, birthday, hobbies, socialNet.GetLastestID);
            socialNet.AddUser(user);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Press any key to get back to menu.");
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
        }
        private static void Option2(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 2 was chosen, moving to removing an existing user system.\n");
            ShowAllUsers(socialNet);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter the username's ID you want to delete (type 'CANCEL' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            int userID = GetUserID(socialNet);
            if (userID == 0)
            {
                Console.ReadKey();
                return;
            }
            try
            {
                User user = socialNet.GetUserByID(userID);
                socialNet.RemoveUser(user);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\nUser {user.GetName} removed successfully!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            catch (Exceptions.UserNotExistException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Press any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option3(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 3 was chosen, moving to adding friends system.\n");
            ShowAllUsers(socialNet);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter the ID of the first user you want to add friend to (type 'CANCEL' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            int userID = GetUserID(socialNet);
            if (userID == 0)
            {
                Console.ReadKey();
                return;
            }
            try
            {
                User user = socialNet.GetUserByID(userID);
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("\nEnter the ID of the second user you want to add friend to (type 'CANCEL' to exit the loop):");
                Console.ForegroundColor = ConsoleColor.White;
                int userID2;
                while (true)
                {
                    userID2 = GetUserID(socialNet);
                    if (userID2 == 0)
                    {
                        Console.ReadKey();
                        return;
                    }
                    if (userID2 == userID)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("You cannot add the same user as friends! Try again!");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                        break;
                }
                User user2 = socialNet.GetUserByID(userID2);
                try
                {
                    socialNet.AddFriend(user, user2);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"\nUser '{user.GetName}' and user '{user2.GetName}' are friends now!\n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                catch (Exceptions.UsersAlreadyFriendsException exx)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\n" + exx.Message + "\n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            catch (Exceptions.UserNotExistException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + ex.Message + "\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Press any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option4(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 4 was chosen, moving to removing friends system.\n");
            ShowAllUsers(socialNet);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter the ID of the first user you want to remove friend to (type 'CANCEL' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            int userID = GetUserID(socialNet);
            if (userID == 0)
            {
                Console.ReadKey();
                return;
            }
            try
            {
                User user = socialNet.GetUserByID(userID);
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("\nEnter the ID of the second user you want to remove friend to (type 'CANCEL' to exit the loop):");
                Console.ForegroundColor = ConsoleColor.White;
                int userID2;
                while (true)
                {
                    userID2 = GetUserID(socialNet);
                    if (userID2 == 0)
                    {
                        Console.ReadKey();
                        return;
                    }
                    if (userID2 == userID)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("You cannot remove the same user from friendship! Try again!");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                        break;
                }
                User user2 = socialNet.GetUserByID(userID2);
                try
                {
                    socialNet.RemoveFriend(user, user2);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"\nUser '{user.GetName}' and user '{user2.GetName}' are no longer friends!\n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                catch (Exceptions.UsersNotFriendsException exx)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\n" + exx.Message + "\n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            catch (Exceptions.UserNotExistException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + ex.Message + "\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Press any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option5(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 5 was chosen, moving to adding hobbies to existing user system.\n");
            ShowAllUsers(socialNet);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter the username's ID you want to add hobbies (type 'CANCEL' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            int userID = GetUserID(socialNet);
            if (userID == 0)
            {
                Console.ReadKey();
                return;
            }
            try
            {
                User user = socialNet.GetUserByID(userID);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"\n{user.GetName}'s hobbies are:\n" +
                    $"{user.GetHobbies}\n");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("List of all available hobbies for you:\n");
                List<string> hobbiesList = new List<string>();
                foreach (Hobbies h in (Hobbies[])Enum.GetValues(typeof(Hobbies)))
                {
                    if (!user.GetHobbies.HasFlag(h))
                        hobbiesList.Add(h.ToString());
                }
                int colCount = 4;
                int rowCount = (int)Math.Ceiling((double)hobbiesList.Count / colCount);
                for (int i = 0; i < rowCount; i++)
                {
                    for (int j = 0; j < colCount; j++)
                    {
                        int index = i + j * rowCount;
                        if (index < hobbiesList.Count)
                        {
                            Console.Write(hobbiesList[index].PadRight(20));
                        }
                    }
                    Console.WriteLine();
                }
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("\nEnter the hobbies you want to add (type 'STOP' to exit the loop):");
                Console.ForegroundColor = ConsoleColor.White;
                Hobbies hobbies = new Hobbies();
                string hob = Console.ReadLine();
                while (!string.Equals(hob, "STOP", StringComparison.OrdinalIgnoreCase))
                {
                    if (Enum.TryParse(hob, true, out Hobbies h))
                    {
                        hobbies |= h;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"Invalid hobby: {hob}");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    hob = Console.ReadLine();
                }
                socialNet.AddHobbies(user, hobbies);
            }
            catch (Exceptions.UserNotExistException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + ex.Message + "\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nPress any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option6(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 6 was chosen, moving to removing hobbies to existing user system.\n");
            ShowAllUsers(socialNet);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter the username's ID you want to remove hobbies (type 'CANCEL' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            int userID = GetUserID(socialNet);
            if (userID == 0)
            {
                Console.ReadKey();
                return;
            }
            try
            {
                User user = socialNet.GetUserByID(userID);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"\n{user.GetName}'s hobbies are:\n" +
                    $"{user.GetHobbies}\n");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("\nEnter the hobbies you want to add (type 'STOP' to exit the loop):");
                Console.ForegroundColor = ConsoleColor.White;
                Hobbies hobbies = user.GetHobbies;
                string hob = Console.ReadLine();
                Hobbies hb = new Hobbies();
                while (!string.Equals(hob, "STOP", StringComparison.OrdinalIgnoreCase))
                {
                    if (Enum.TryParse(hob, true, out Hobbies h) && hobbies.HasFlag(h))
                    {
                        hb |= h;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"Invalid hobby: {hob}");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    hob = Console.ReadLine();
                }
                socialNet.RemoveHobbiers(user, hb);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"\nUser {user.GetName}\nSuccessfully removed hobbies: {hb}");
                Console.ForegroundColor = ConsoleColor.White;
            }
            catch (Exceptions.UserNotExistException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + ex.Message + "\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nPress any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option7(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 7 was chosen, moving to showing user's friend list system.\n");
            ShowAllUsers(socialNet);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter the username's ID you want to see his friend list (type 'CANCEL' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            int userID = GetUserID(socialNet);
            if (userID == 0)
            {
                Console.ReadKey();
                return;
            }
            try
            {
                User user = socialNet.GetUserByID(userID);
                List<User> friendList = socialNet.FriendsList(user);
                string friends = "";
                if (friendList.Count > 0)
                {
                    foreach (var f in friendList)
                    {
                        friends += f.GetName + ", ";
                    }
                    friends = friends.Substring(0, friends.Length - 2);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"\n{user.GetName}'s friend list:\n" +
                        $"{friends}\n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"\n{user.GetName} has no friends\n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            catch (Exceptions.UserNotExistException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + ex.Message + "\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nPress any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option8(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 8 was chosen, moving to showing user's people you might know list system.\n");
            ShowAllUsers(socialNet);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter the username's ID you want to see his people you might know list (type 'CANCEL' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            int userID = GetUserID(socialNet);
            if (userID == 0)
            {
                Console.ReadKey();
                return;
            }
            try
            {
                User user = socialNet.GetUserByID(userID);
                List<User> mightKnow = socialNet.PeopleYouMayKnow(user);
                string people = "";
                if (mightKnow.Count > 0)
                {
                    foreach (var f in mightKnow)
                    {
                        people += f.GetName + ", ";
                    }
                    people = people.Substring(0, people.Length - 2);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"\n{user.GetName}'s people you might know list:\n" +
                        $"{people}\n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"\n{user.GetName} has no people you might know\n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            catch (Exceptions.UserNotExistException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + ex.Message + "\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nPress any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option9(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 9 was chosen, moving to show user's information system.\n");
            ShowAllUsers(socialNet);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter the username's ID you want to see his information (type 'CANCEL' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            int userID = GetUserID(socialNet);
            if (userID == 0)
            {
                Console.ReadKey();
                return;
            }
            try
            {
                User user = socialNet.GetUserByID(userID);
                string info = socialNet.ShowUserInfo(user);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\n{info}\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            catch (Exceptions.UserNotExistException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + ex.Message + "\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nPress any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option10(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 10 was chosen, moving to creaating new user's post system.\n");
            ShowAllUsers(socialNet);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter the username's ID you want to add a post to (type 'CANCEL' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            int userID = GetUserID(socialNet);
            if (userID == 0)
            {
                Console.ReadKey();
                return;
            }
            try
            {
                User user = socialNet.GetUserByID(userID);
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"\nYou chose user {user.GetName}.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("\nEnter title's head:\n");
                Console.ForegroundColor = ConsoleColor.White;
                string title = Console.ReadLine();
                while (title.Length < 3)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nInvalid post's title! Try again!\n");
                    Console.ForegroundColor = ConsoleColor.White;
                    title = Console.ReadLine();
                }
                title = title[0].ToString().ToUpper() + title.Substring(1, title.Length - 1).ToLower();
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("\nEnter post's body:\n");
                Console.ForegroundColor = ConsoleColor.White;
                string body = Console.ReadLine();
                while (body.Length < 3)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nInvalid post's body! Try again!\n");
                    Console.ForegroundColor = ConsoleColor.White;
                    body = Console.ReadLine();
                }
                body = body[0].ToString().ToUpper() + body.Substring(1, body.Length - 1).ToLower();
                Post post = new Post(title, body);
                try
                {
                    socialNet.AddPost(user, post);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"\nNew post has added to {user.GetName}\n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                catch (Exceptions.PostExistException x)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\n" + x.Message + "\n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            catch (Exceptions.UserNotExistException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + ex.Message + "\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nPress any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option11(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 11 was chosen, moving to show user's post system.\n");
            ShowAllUsers(socialNet);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter the username's ID you want to view his post (type 'CANCEL' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            int userID = GetUserID(socialNet);
            if (userID == 0)
            {
                Console.ReadKey();
                return;
            }
            try
            {
                User user = socialNet.GetUserByID(userID);
                string titles = string.Empty;
                if (user.GetPosts.Count > 0)
                {
                    foreach (Post pst in user.GetPosts)
                    {
                        titles += pst.GetTitle + "\n";
                    }
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"\n{user.GetName}'s Posts:\n{titles}");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("Enter the full title of the post you want to view (type 'STOP' to exit the loop):");
                    Console.ForegroundColor = ConsoleColor.White;
                    string choice;
                    while (true)
                    {
                        choice = Console.ReadLine();
                        if (string.Equals(choice, "STOP", StringComparison.OrdinalIgnoreCase))
                        {
                            return;
                        }
                        foreach (Post p in user.GetPosts)
                        {
                            if (string.Equals(choice, p.GetTitle, StringComparison.OrdinalIgnoreCase))
                            {
                                try
                                {
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine($"\n{socialNet.ShowPost(user, p)}");
                                    Console.ForegroundColor = ConsoleColor.White;
                                    return;
                                }
                                catch (Exceptions.PostNotExistException x)
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("\n" + x.Message + "\n");
                                    Console.ForegroundColor = ConsoleColor.White;
                                    return;
                                }
                            }
                        }
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\nThe post: " + choice + " not found!" + "\n");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\n" + user.GetName + " has no posts!" + "\n");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            catch (Exceptions.UserNotExistException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + ex.Message + "\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nPress any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option12(SocialNet socialNet)
        {
            Console.Clear();
            Console.WriteLine("Option 12 was chosen, moving to show user's posts by dates system.\n");
            ShowAllUsers(socialNet);
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nEnter the username's ID you want to view his posts by dates (type 'CANCEL' to exit the loop):");
            Console.ForegroundColor = ConsoleColor.White;
            int userID = GetUserID(socialNet);
            if (userID == 0)
            {
                Console.ReadKey();
                return;
            }
            try
            {
                User user = socialNet.GetUserByID(userID);
                if (user.GetPosts.Count > 0)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"\nYou chose user {user.GetName}'s posts!");
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($"\nChoose the first date:");
                    Console.ForegroundColor = ConsoleColor.White;
                    DateTime firstDate;
                    while (true)
                    {
                        if (DateTime.TryParse(Console.ReadLine(), out firstDate))
                        {
                            if (firstDate <= DateTime.Today.Date)
                                break;
                        }
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid date, try again!");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($"\nChoose the second date:");
                    Console.ForegroundColor = ConsoleColor.White;
                    DateTime secondDate;
                    while (true)
                    {
                        if (DateTime.TryParse(Console.ReadLine(), out secondDate))
                        {
                            if (secondDate <= DateTime.Today.Date && secondDate.Date != firstDate.Date)
                                break;
                        }
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid date, try again!");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    if (secondDate.Date < firstDate.Date)
                    {
                        DateTime temp = secondDate;
                        secondDate = firstDate;
                        firstDate = temp;
                    }
                    List<string> posts = socialNet.ShowPostsByUserByDates(user, firstDate, secondDate);
                    if (posts.Count > 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine($"\nAll the posts for {user.GetName} between dates {firstDate:d} to {secondDate:d} are:");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(string.Join("", posts));
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("\nTo view one of the posts you can go back to menu and choose option 11!");
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\n" + user.GetName + " has no posts between the dates you've given!");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\n" + user.GetName + " has no posts!");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            catch (Exceptions.UserNotExistException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + ex.Message + "\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nPress any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option13(SocialNet socialNet, DateTime date)
        {
            Console.Clear();
            Console.WriteLine($"Option 13 was chosen, moving to showing the users celebrating birthday today ({date:d}).\n");
            try
            {
                List<User> bday = socialNet.GetTodaysBirthday(date);
                Console.ForegroundColor= ConsoleColor.Blue;
                Console.WriteLine("The celebrating users are:");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ForegroundColor = ConsoleColor.Yellow;
                foreach (var user in bday)
                {
                    int age = date.Year - user.GetBirthDay.Year;
                    Console.WriteLine($"\n{user.GetName} celebrates the age of: {age}");
                }
                Console.ForegroundColor = ConsoleColor.White;
            }
            catch (Exceptions.NoBirthdaysInThisDateException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\n" + ex.Message + "\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
            finally
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nPress any key to get back to menu.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadKey();
            }
        }
        private static void Option14(ref DateTime date)
        {
            date = date.AddDays(1);
        }
        private static void ShowAllUsers(SocialNet socialNet)
        {
            Console.WriteLine("Here are all the users in the social net:");
            List<string> users = socialNet.GetUsernamesAndID;
            int colCount = 4;
            int rowCount = (int)Math.Ceiling((double)users.Count / colCount);
            for (int i = 0; i < rowCount; i++)
            {
                for (int j = 0; j < colCount; j++)
                {
                    int index = i + j * rowCount;
                    if (index < users.Count)
                    {
                        Console.Write(users[index] + "\t");
                    }
                }
                Console.WriteLine();
            }
        }
        private static int GetUserID(SocialNet socialNet)
        {
            while (true)
            {
                string ID = Console.ReadLine();
                if (string.Equals(ID, "CANCEL", StringComparison.OrdinalIgnoreCase))
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("\nPress any key to get back to menu.");
                    Console.ForegroundColor = ConsoleColor.White;
                    return 0;
                }
                if (int.TryParse(ID, out int userID) && socialNet.GetID.Contains(userID))
                    return userID;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid ID was entered! Try again!");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
    }
}
